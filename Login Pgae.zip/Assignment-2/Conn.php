<?php 
    
    $conn = new mysqli("localhost","root","","mydb");
?>